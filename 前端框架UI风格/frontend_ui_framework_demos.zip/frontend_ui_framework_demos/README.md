# 前端 UI 框架风格 · 单文件 HTML Demo

包含 6 个可直接在浏览器打开的独立演示：

1. `01-element-ui-style.html` — Element UI 风格
2. `02-ant-design-style.html` — Ant Design 风格
3. `03-mui-style.html` — Material UI 风格
4. `04-bootstrap-style.html` — Bootstrap 5 风格
5. `05-tailwind-shadcn-style.html` — Tailwind / shadcn 风格
6. `06-fluent-ui-style.html` — Fluent UI 风格

## 如何运行

- 下载 ZIP 并解压。
- 双击任一 `.html` 文件，使用 Chrome、Firefox、Edge 等浏览器打开即可。
- 不需要安装 Node.js，不需要 npm，不需要启动本地服务，也不依赖 CDN / 网络连接。

## 可以体验的交互

- 左侧导航切换
- 搜索过滤项目
- 新建项目弹窗并把项目添加到列表
- 项目详情提示、通知、使用指南
- 切换图表时间范围
- 移动端响应式布局

说明：这是为方便对比视觉风格制作的原生 HTML/CSS/JavaScript 自包含 Demo，**模拟各框架常见的设计语言**，并不是把各官方组件库直接打包进文件。因此适合快速预览、选型和演示；实际开发时如需官方组件、主题系统和 API，需要按对应框架的官方安装方式接入。
